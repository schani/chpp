#ifndef YYSTYPE
#define YYSTYPE int
#endif
#define	T_OR	258
#define	T_AND	259
#define	T_EQ	260
#define	T_NE	261
#define	T_LE	262
#define	T_GE	263
#define	NEG	264
#define	T_NUM	265
#define	T_IDENT	266


extern YYSTYPE yylval;
